module.exports = {
  skipFiles: ['libraries', 'mocks']
};