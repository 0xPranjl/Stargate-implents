const SANDBOX_CHAIN_IDS = [
    20001,
    20002,
    20004,
    20006,
    20009
];

module.exports = SANDBOX_CHAIN_IDS;