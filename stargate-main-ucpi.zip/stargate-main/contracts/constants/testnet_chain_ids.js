const TESTNET_CHAIN_IDS = [
    10001,
    10002,
    10004,
    10005,
    10006,
    10009
];

module.exports = TESTNET_CHAIN_IDS;